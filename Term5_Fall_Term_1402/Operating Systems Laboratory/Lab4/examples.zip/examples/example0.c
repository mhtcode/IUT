#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void task();

int main()
{
	pid_t pid;
	int status;
	
	while(1){
		pid = fork();
		if(pid == 0) {
			task();
		}
		wait(&status);
		printf("returned status : %d, real status %d \n", status, WEXITSTATUS(status));
	}
	
	return 0;
}

void task(){
	srand(time(NULL) + getpid());
	int r= rand()%5;
	sleep(r);
	printf("%d : my random is %d\n", getpid(),r);
	exit (r);
}
